//---------------------------------------------------------------------------

#ifndef UParseLineH
#define UParseLineH
//---------------------------------------------------------------------------
#include <vcl.h>
TStringList * ParseCmdLine(AnsiString par,char delimiter);
#endif
