#ifndef USEALLEGRO_H
#define USEALLEGRO_H
#include "allegro.h"
#include "winalleg.h"
#include <vcl.h>

//class TAllegroPtrs
//{
//public:
//		HWND AllegroWnd;
//		BITMAP * bmpCanvas;		// User declarations
//};
#endif
 